# Papers app initialization

