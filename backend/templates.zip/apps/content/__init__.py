# Content app initialization

