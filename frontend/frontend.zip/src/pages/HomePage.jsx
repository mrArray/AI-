import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import Header from '../components/Header';
import Footer from '../components/Footer';
import DocumentGenerator from '../components/DocumentGenerator';
import DocumentFormatter from '../components/DocumentFormatter';

function HomePage() {
  const { t } = useTranslation('home');
  const [activeMode, setActiveMode] = useState('formatter'); // 默认显示排版功能
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-100 flex flex-col">
      <Header activePage="home" />

      {/* Hero + Core Features Combined Section */}
      <div className={`relative transition-all duration-500 ${
        activeMode === 'formatter' 
          ? 'bg-gradient-to-br from-purple-50 to-violet-100' 
          : 'bg-gradient-to-br from-sky-50 to-blue-100'
      }`}>
        {/* Hero Background Decoration */}
        <div className={`absolute inset-0 opacity-10 transform skew-y-3 -translate-y-10 transition-all duration-500 ${
          activeMode === 'formatter'
            ? 'bg-gradient-to-r from-purple-500 to-violet-600'
            : 'bg-gradient-to-r from-sky-500 to-blue-600'
        }`}></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          {/* Hero Content */}
          <div className="text-center pt-16 md:pt-20 pb-8">
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 tracking-tight">
              <span className="block">{t('hero.title1')}</span>
              <span className={`block mt-2 bg-clip-text text-transparent transition-all duration-500 ${
                activeMode === 'formatter'
                  ? 'bg-gradient-to-r from-purple-600 to-violet-600'
                  : 'bg-gradient-to-r from-sky-600 to-blue-600'
              }`}>
                {t('hero.title2')}
              </span>
            </h1>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-600">
              {t('hero.description')}
            </p>
          </div>
          
          {/* 功能切换选项卡 - 集成在Hero中 */}
          <div className="flex justify-center mb-8">
            <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-2 shadow-xl border border-white/20">
              <div className="flex space-x-2">
                <button
                  onClick={() => setActiveMode('formatter')}
                  className={`px-6 py-3 rounded-xl font-bold transition-all duration-300 flex items-center ${
                    activeMode === 'formatter'
                      ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-lg'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
                  }`}
                >
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                  </svg>
                  {t('functionTabs.formatter')}
                </button>
                    <button 
                  onClick={() => setActiveMode('generator')}
                  className={`px-6 py-3 rounded-xl font-bold transition-all duration-300 flex items-center ${
                    activeMode === 'generator'
                      ? 'bg-gradient-to-r from-sky-600 to-blue-600 text-white shadow-lg'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
                  }`}
                >
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                  {t('functionTabs.generator')}
                      </button>
              </div>
            </div>
          </div>

          {/* 功能内容区域 */}
          <div className="pb-12 transition-all duration-500 ease-in-out">
            {activeMode === 'formatter' ? <DocumentFormatter /> : <DocumentGenerator />}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-gradient-to-br from-indigo-50 to-blue-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-indigo-600 font-semibold tracking-wide uppercase">
              {t('features.subtitle')}
            </h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              {t('features.title')}
            </p>
          </div>
          
          <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
            {['speed', 'plagiarism', 'templates'].map((feature) => (
              <div key={feature} className="bg-white rounded-2xl p-8 shadow-xl border border-indigo-100 transform transition hover:-translate-y-2">
              <div className="bg-indigo-100 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {t(`features.items.${feature}.title`)}
                </h3>
              <p className="text-gray-600">
                  {t(`features.items.${feature}.content`)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-indigo-600 font-semibold tracking-wide uppercase">
              {t('testimonials.subtitle')}
            </h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              {t('testimonials.title')}
            </p>
          </div>
          
          <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
            {['student', 'professor', 'researcher'].map((role) => (
              <div key={role} className="bg-gray-50 rounded-2xl p-8 border border-gray-200">
              <div className="flex items-center mb-4">
                <div className="bg-gray-200 border-2 border-dashed rounded-xl w-12 h-12" />
                <div className="ml-4">
                    <h4 className="font-bold">{t(`testimonials.items.${role}.name`)}</h4>
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">
                  {t(`testimonials.items.${role}.content`)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            {t('cta.title')}
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-indigo-200">
            {t('cta.description')}
          </p>
          <div className="mt-8 flex justify-center">
            <button 
              onClick={() => window.location.href = '/register'}
              className="bg-white text-indigo-600 px-8 py-3 rounded-xl font-bold text-lg shadow-lg hover:bg-indigo-50 transition"
            >
              {t('cta.register')}
            </button>
            <button 
              onClick={() => window.location.href = '/login'}
              className="ml-4 bg-indigo-800 text-white px-8 py-3 rounded-xl font-bold text-lg shadow-lg hover:bg-indigo-900 transition"
            >
              {t('cta.demo')}
            </button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default HomePage;
           
           