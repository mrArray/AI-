# Billing app initialization

