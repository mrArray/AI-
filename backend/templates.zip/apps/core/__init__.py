# Core app initialization

